﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace GestionDepenses.ViewModels;

public class BaseViewModel : INotifyPropertyChanged
{
    private bool isBusy;
    public bool IsBusy
    {
        get => isBusy;
        set { isBusy = value; OnPropertyChanged(); }
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    protected void OnPropertyChanged([CallerMemberName] string? name = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}