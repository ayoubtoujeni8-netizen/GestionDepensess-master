[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "GestionDepenses")]
[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "GestionDepenses.Pages")]
