﻿using SQLite;
using GestionDepenses.Models;

namespace GestionDepenses.Services;

public class ExpenseService
{
    private SQLiteAsyncConnection? _db;

    private async Task Init()
    {
        if (_db != null) return;
        var path = Path.Combine(FileSystem.AppDataDirectory, "expenses.db3");
        _db = new SQLiteAsyncConnection(path);
        await _db.CreateTableAsync<Expense>();
    }

    public async Task<List<Expense>> GetAllAsync()
    {
        await Init();
        return await _db!.Table<Expense>().OrderByDescending(e => e.Date).ToListAsync();
    }

    public async Task AddAsync(Expense e) { await Init(); await _db!.InsertAsync(e); }
    public async Task DeleteAsync(Expense e) { await Init(); await _db!.DeleteAsync(e); }
}