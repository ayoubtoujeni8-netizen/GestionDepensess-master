﻿using System.Windows.Input;
using GestionDepenses.Models;
using GestionDepenses.Services;

namespace GestionDepenses.ViewModels;

public class AddExpenseViewModel : BaseViewModel
{
    private readonly ExpenseService _service = new();

    public string Title { get; set; } = "";
    public double Amount { get; set; }
    public string Category { get; set; } = "";
    public DateTime Date { get; set; } = DateTime.Today;
    public ICommand SaveCommand { get; }

    public AddExpenseViewModel()
    {
        SaveCommand = new Command(async () => await Save());
    }

    private async Task Save()
    {
        if (string.IsNullOrWhiteSpace(Title) || Amount <= 0) return;
        await _service.AddAsync(new Expense
        {
            Title = Title,
            Amount = Amount,
            Category = Category,
            Date = Date
        });
        await Shell.Current.GoToAsync("..");
    }
}