﻿using System.Collections.ObjectModel;
using System.Windows.Input;
using GestionDepenses.Models;
using GestionDepenses.Services;

namespace GestionDepenses.ViewModels;

public class ExpensesViewModel : BaseViewModel
{
    private readonly ExpenseService _service = new();
    public ObservableCollection<Expense> Expenses { get; } = new();

    private double total;
    public double Total { get => total; set { total = value; OnPropertyChanged(); } }

    public ICommand LoadCommand { get; }
    public ICommand DeleteCommand { get; }

    public ExpensesViewModel()
    {
        LoadCommand = new Command(async () => await Load());
        DeleteCommand = new Command<Expense>(async e =>
        {
            await _service.DeleteAsync(e);
            await Load();
        });
    }

    private async Task Load()
    {
        if (IsBusy) return;
        try
        {
            IsBusy = true;
            Expenses.Clear();
            var list = await _service.GetAllAsync();
            foreach (var e in list) Expenses.Add(e);
            Total = list.Sum(e => e.Amount);
        }
        finally { IsBusy = false; }
    }
}