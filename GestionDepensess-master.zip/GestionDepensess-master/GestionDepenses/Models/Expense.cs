﻿using SQLite;

namespace GestionDepenses.Models;

public class Expense
{
    [PrimaryKey, AutoIncrement]
    public int Id { get; set; }
    public string Title { get; set; } = "";
    public double Amount { get; set; }
    public DateTime Date { get; set; } = DateTime.Today;
    public string Category { get; set; } = "";
}